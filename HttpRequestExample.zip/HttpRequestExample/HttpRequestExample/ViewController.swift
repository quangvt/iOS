//
//  ViewController.swift
//  HttpRequestExample
//
//  Created by Đỗ Thanh Tâm on 4/19/17.
//  Copyright © 2017 TAMDO. All rights reserved.
//

import UIKit
import Social

class ViewController: UIViewController {

    
    //MARK: Properties
    @IBOutlet weak var imageView: UIImageView!
    
    
    
    //Default
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    
    //MARK: Actions
    
    @IBAction func buttonShare(_ sender: Any) {
        
        //Another way to share
        let activityVC = UIActivityViewController(activityItems: [self.imageView.image], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        
        self.present(activityVC, animated: true, completion: nil)

        
        
//        let alert = UIAlertController(title: "Share", message: "Share the poem of the day!", preferredStyle: .actionSheet)
//        
//        //First action
//        let actionOne = UIAlertAction(title: "Share on Facebook", style: .default, handler:
//        { (action) in
//            //Check if user is connected to Facebook
//            if SLComposeViewController.isAvailable(forServiceType: SLServiceTypeFacebook)
//            {
//                let post = SLComposeViewController(forServiceType: SLServiceTypeFacebook)!
//                
//                post.setInitialText("Poem of the day")
//                
//                post.add(self.imageView.image)
//                
//                self.present(post, animated: true, completion: nil)
//            } else
//            {
//                self.showAlert(service: "Facebook")
//            }
//        })
//        
//        //Second action
//        let actionTwo = UIAlertAction(title: "Share on Twitter", style: .default, handler:
//        { (action) in
//            //Check if user is connected to Twitter
//            if SLComposeViewController.isAvailable(forServiceType: SLServiceTypeTwitter)
//            {
//                let post = SLComposeViewController(forServiceType: SLServiceTypeTwitter)!
//                
//                post.setInitialText("Poem of the day")
//                
//                post.add(self.imageView.image)
//                
//                self.present(post, animated: true, completion: nil)
//            } else
//            {
//                self.showAlert(service: "Twitter")
//            }
//        })
//        
//        //Third action
//        let actionThree = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
//        
//        //Add action to action sheet
//        alert.addAction(actionOne)
//        alert.addAction(actionTwo)
//        alert.addAction(actionThree)
//        
//        //Present alert
//        self.present(alert, animated: true, completion: nil)
    }
    
    func showAlert(service: String)
    {
        let alert = UIAlertController(title: "Error", message: "You are not connected to \(service)", preferredStyle: .alert)
        let action = UIAlertAction(title: "Dismiss", style: .cancel, handler: nil)
        
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }

}

