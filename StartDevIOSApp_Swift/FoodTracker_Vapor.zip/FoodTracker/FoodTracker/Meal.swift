import UIKit

class Meal {
    
    //MARK: Properties
    var id: Int
    var name: String
    var photo: UIImage?
    var description: String
    var rating: Int
    
    var strUrl = "http://localhost:8080/meals"
    
    //MARK: Initialization
    init?(id: Int, name: String, photo: UIImage?, description: String, rating: Int) {
        
        //the name must not be empty
        guard !name.isEmpty else {
            return nil
        }
        
        // The rating must be between 0 and 5 inclusively
        guard (rating >= 0) && (rating <= 5) else {
            return nil
        }
        
        
        //Initialize stored properties.
        self.id = id
        self.name = name
        self.photo = photo
        self.description = name.replacingOccurrences(of: " ", with: "_").appending(".png") //(".jpg")
        self.rating = rating
        
    }
    
    //Insert to DB
    func insert() {
        
        let baseUrl = NSURL(string: strUrl)
        
        let request = NSMutableURLRequest(url: baseUrl! as URL)
        
        request.httpMethod = "POST";
        
        let param = [
            "name"  : "\(name)",
            "desc"    : "\(description)",
            "rating"    : "\(rating)"
        ]
        
        let boundary = generateBoundaryString()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        let imageData = UIImagePNGRepresentation(photo!) //UIImageJPEGRepresentation(photo!, 1)
        
        if(imageData==nil)  { return; }
        
        request.httpBody = createBodyWithFile(parameters: param, filePathKey: "file", imageDataKey: imageData! as NSData, boundary: boundary) as Data
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(String(describing: error))")
                return
            }
            
            // You can print out response object
            print("=> response = \(String(describing: response))")
            
            // Print out reponse body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("=> response data = \(responseString!)")
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary
                
                print(json as Any)
                if let parseJson = json as? [String: AnyObject] {
                    self.id = parseJson["id"] as! Int
                }
                
            } catch
            {
                print(error)
            }
            
        }
        
        task.resume()

    }
    
    //Update to DB
    func update() {
        
        strUrl += "/\(id)" //For updating

        let baseUrl = NSURL(string: strUrl)
        
        let request = NSMutableURLRequest(url: baseUrl! as URL);
        request.httpMethod = "PUT";
        
        let param = [
            "id" : "\(id)",
            "name"  : "\(name)",
            "rating"    : "\(rating)"
        ]
        
        let boundary = generateBoundaryString()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        request.httpBody = createBodyWithParameters(parameters: param, boundary: boundary) as Data
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            if error != nil {
                fatalError("Cannot connect to Server!")
            }
            
            //Print response object
            print("=> response: \(String(describing: response))")
            
            //Print response body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("=> responseBody: \(String(describing: responseString))")
            
            //var err: NSError?
            if data != nil {
                do {
                    let json = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    
                    print("Result: \(json)")
                    
                }
                catch {
                    fatalError("Cannot insert into Database!")
                }
            }
        }
        task.resume()
    }
    
    //Create HTTP Body
    func createBodyWithParameters(parameters: [String: String]?, boundary: String) -> NSData {
        let body = NSMutableData();
        
        if parameters != nil {
            for (key, value) in parameters! {
                body.appendString(string: "--\(boundary)\r\n")
                body.appendString(string: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
                body.appendString(string: "\(value)\r\n")
            }
        }
        
        body.appendString(string: "--\(boundary)\r\n")
        
        return body
    }
    
    //Create HTTP Body with FILE
    func createBodyWithFile(parameters: [String: String]?, filePathKey: String?, imageDataKey: NSData, boundary: String) -> NSData {
        let body = NSMutableData();
        
        if parameters != nil {
            for (key, value) in parameters! {
                body.appendString(string: "--\(boundary)\r\n")
                body.appendString(string: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
                body.appendString(string: "\(value)\r\n")
            }
        }
        
        let filename = (parameters?["desc"])!
        let mimetype = "image/png" // "image/jpg"
        
        body.appendString(string: "--\(boundary)\r\n")
        body.appendString(string: "Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n")
        body.appendString(string: "Content-Type: \(mimetype)\r\n\r\n")
        body.append(imageDataKey as Data)
        body.appendString(string: "\r\n")
        body.appendString(string: "--\(boundary)--\r\n")
        
        return body
    }
    
    
    //Generate Boudary
    func generateBoundaryString() -> String {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    //Delete Meal
    func delete() {
        
        strUrl += "/\(id)"
        
        let baseUrl = NSURL(string: strUrl)
        
        let request = NSMutableURLRequest(url: baseUrl! as URL);
        request.httpMethod = "DELETE";
        
        let postString = "id=\(id)"
        
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { (data, response, myerror) in
            if myerror != nil {
                fatalError("Cannot connect to Server!")
            }
            
            //Print response object
            print("=> response: \(String(describing: response))")
            
            //Print response body
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("=> responseBody: \(String(describing: responseString))")
            
            //var err: NSError?
            if data != nil {
                do {
                    let json = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    
                    print("Result: \(json)")
                    
                }
                catch {
                    fatalError("Cannot insert into Database!")
                }
            }
        }
        task.resume()
    }
    
}
extension NSMutableData {
    
    func appendString(string: String) {
        let data = string.data(using: String.Encoding.utf8, allowLossyConversion: true)
        append(data!)
    }
}
