import UIKit
import os.log

class MealTableViewController: UITableViewController {
    
    //MARK: Properties
    var meals = [Meal]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Use the edit button item provided by the table view controller
        navigationItem.leftBarButtonItem = editButtonItem

        //Load all Meals from DB
        loadMeals()

    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return meals.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Table view cells are reused anf should be dequeued using cell identifier
        let cellIdentifier = "MealTableViewCell"
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? MealTableViewCell else {
            fatalError("The dequeued cell is not an instance of MealTableViewCell.")
        }
        
        //Fetches the appropriate meal for the data source layout
        let meal = meals[indexPath.row]
        
        //Config the cell
        cell.nameLabel.text = meal.name
        cell.photoImageView.image = meal.photo
        cell.ratingControl.rating = meal.rating
    
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let meal = meals[indexPath.row]
            meal.delete()
            
            meals.remove(at: indexPath.row)
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        super.prepare(for: segue, sender: sender)
        
        switch (segue.identifier ?? "") {
            
        case "AddItem":
            os_log("Adding a new meal", log: OSLog.default, type: .debug)
            
        case "ShowDetail":
            guard let detailMealViewController = segue.destination as? MealViewController else {
                fatalError("Unexpected destination: \(segue.destination)")
            }
            
            guard let selectedMealCell = sender as? MealTableViewCell else {
                    fatalError("Unexpected sender: \(String(describing: sender))")
            }
            
            guard let indexPath = tableView.indexPath(for: selectedMealCell) else {
                fatalError("The selected cell is not being displayed by the table")
            }
            
            //Update to Table view
            let selectedMeal = meals[indexPath.row]
            detailMealViewController.meal = selectedMeal
            
        default:
            fatalError("Unexpected Segue Identifier: \(String(describing: segue.identifier))")
        }
    }
    
    
    
    //MARK: Action
    @IBAction func unwindToMealList(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.source as? MealViewController, let meal = sourceViewController.meal {
            
            if let selectedIndexPath = tableView.indexPathForSelectedRow {
                //Update an existing meal
                meals[selectedIndexPath.row] = meal
                tableView.reloadRows(at: [selectedIndexPath], with: .none)
                
                //Update DB
                meal.update()
                
            } else {
                // Add a new meal
                let newIndexPath = IndexPath(row: meals.count, section: 0)
                
                //Insert DB
                meal.insert()
                
                meals.append(meal)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
        }
    }
    
    //Load meal from Database
    private func loadMeals()
    {
        
        let url = URL(string:"http://localhost:8080/meals")
        let task = URLSession.shared.dataTask(with: url!)
        { (data, response, error) in
            
            var id: Int? = nil
            var name: String? = nil
            var description: String? = nil
            var rating: Int? = nil
            
            if error != nil
            {
                fatalError("Link is invalid!")
            }

            do
            {
                //Array of Meal from DB
                let myJson = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [Any]
                
                //Convert from JSON to Meal object
                for index in 0..<myJson.count
                {
                    if let dictionary = myJson[index] as? [String: Any]
                    {
                        id = dictionary["id"]! as? Int
                        
                        name = dictionary["name"] as? String
                        
                        rating = dictionary["rating"] as? Int
                        
                        description = dictionary["desc"] as? String
                        
                        //photo = UIImage(named: description!)
                        
                    }
                    guard let meal = Meal(id: id!, name: name!, photo: nil, description: description!, rating: rating!) else
                    {
                        fatalError("Cannot create Meal!")
                    }
            
                    if let checkedUrl = URL(string: "http://localhost:8080/images/" + description!) {
                        let photoTask = URLSession.shared.dataTask(with: checkedUrl) { (data, response, error) in
                            guard let data = data, error == nil else { return }
                            DispatchQueue.main.async{
                                
                                meal.photo = UIImage(data: data)
                                
                            }
                        }
                        photoTask.resume()
                    }
                    
                    self.meals.append(meal)
                    
                    DispatchQueue.main.async{
                        self.tableView.reloadData()
                    }
                    
                }
            }
            catch
            {
                fatalError("What is the f**k!")
            }

        }
        
        task.resume()
        
    }
    
}
